package fr.objectifs.mensuels

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import java.text.DateFormatSymbols
import java.util.Calendar
import kotlin.math.max

private const val MAX_OBJECTIVES = 20
private val Black = Color(0xFF050505)
private val White = Color.White
private val Grid = Color(0xFF111111)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppHolder.prefs = getSharedPreferences("objectifs", MODE_PRIVATE)
        setContent { App() }
    }
}

@Composable
fun App() {
    val cal = remember { Calendar.getInstance() }
    var month by remember { mutableIntStateOf(cal.get(Calendar.MONTH)) }
    var year by remember { mutableIntStateOf(cal.get(Calendar.YEAR)) }

    val days = remember(month, year) {
        Calendar.getInstance().apply { set(year, month, 1) }.getActualMaximum(Calendar.DAY_OF_MONTH)
    }

    val key = "$year-$month"
    var objectives by remember(key) { mutableStateOf(loadObjectives(key)) }
    var states by remember(key) { mutableStateOf(loadStates(key, MAX_OBJECTIVES, days)) }

    fun persist() {
        saveObjectives(key, objectives)
        saveStates(key, states)
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Black) {
        Column(Modifier.fillMaxSize().padding(top = 18.dp)) {
            Text(
                "OBJECTIFS MENSUELS",
                color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
            Spacer(Modifier.height(8.dp))
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = {
                    if (month == 0) { month = 11; year-- } else month--
                }) { Text("‹", color = White, fontSize = 32.sp) }

                Text(
                    "${DateFormatSymbols().months[month].uppercase()} $year",
                    color = White, fontWeight = FontWeight.Bold, fontSize = 17.sp
                )

                TextButton(onClick = {
                    if (month == 11) { month = 0; year++ } else month++
                }) { Text("›", color = White, fontSize = 32.sp) }
            }

            val daily = (0 until days).map { d ->
                (0 until MAX_OBJECTIVES).count { states.getOrNull(it)?.getOrNull(d) == 1 }
            }
            LineChart(daily, Modifier.fillMaxWidth().height(180.dp).padding(horizontal = 16.dp))

            val totalDone = daily.sum()
            val totalFailed = (0 until MAX_OBJECTIVES).sumOf { r ->
                (0 until days).count { states.getOrNull(r)?.getOrNull(it) == 2 }
            }
            val filled = (0 until MAX_OBJECTIVES).sumOf { r ->
                (0 until days).count { states.getOrNull(r)?.getOrNull(it) != 0 }
            }
            val rate = if (filled == 0) 0 else totalDone * 100 / filled

            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly) {
                Stat("✅", totalDone.toString())
                Stat("❌", totalFailed.toString())
                Stat("Réussite", "$rate%")
            }

            RoutineTable(
                objectives = objectives,
                states = states,
                days = days,
                onObjectiveChange = { i, value ->
                    objectives = objectives.toMutableList().also { it[i] = value }
                    persist()
                },
                onStateChange = { r, d ->
                    val copy = states.map { it.toMutableList() }.toMutableList()
                    // Cycle: empty(0) -> success(1) -> empty(0) -> fail(2) -> empty(0)
                    copy[r][d] = when (copy[r][d]) {
                        0 -> 1
                        1 -> 0
                        2 -> 0
                        else -> 0
                    }
                    // To reach failure, a long press is used as a deliberate third state action.
                    states = copy
                    persist()
                },
                onFailure = { r, d ->
                    val copy = states.map { it.toMutableList() }.toMutableList()
                    copy[r][d] = 2
                    states = copy
                    persist()
                }
            )
        }
    }
}

@Composable
fun Stat(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = White, fontSize = 13.sp)
        Text(value, color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun LineChart(values: List<Int>, modifier: Modifier = Modifier) {
    Canvas(modifier.background(Color(0xFF0B0B0B), RoundedCornerShape(12.dp)).border(1.dp, Color.DarkGray, RoundedCornerShape(12.dp))) {
        if (values.isEmpty()) return@Canvas
        val maxV = max(1, values.maxOrNull() ?: 1)
        val left = 28f
        val top = 20f
        val right = size.width - 12f
        val bottom = size.height - 24f
        val w = right - left
        val h = bottom - top
        repeat(4) { i ->
            val y = top + h * i / 3f
            drawLine(Color.DarkGray, Offset(left, y), Offset(right, y), 1f)
        }
        val pts = values.mapIndexed { i, v ->
            Offset(left + if (values.size == 1) w / 2 else w * i / (values.size - 1), bottom - h * v / maxV)
        }
        for (i in 0 until pts.size - 1) drawLine(Color.White, pts[i], pts[i + 1], 4f)
        pts.forEach { drawCircle(Color.White, 4f, it) }
    }
}

@Composable
fun RoutineTable(
    objectives: List<String>, states: List<List<Int>>, days: Int,
    onObjectiveChange: (Int, String) -> Unit,
    onStateChange: (Int, Int) -> Unit,
    onFailure: (Int, Int) -> Unit
) {
    val hScroll = rememberScrollState()
    Column(
        Modifier.padding(top = 4.dp).fillMaxWidth()
            .background(White, RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
            .horizontalScroll(hScroll)
    ) {
        Row(Modifier.height(44.dp)) {
            Cell("OBJECTIF", 150.dp, true)
            for (d in 1..days) Cell(d.toString(), 42.dp, true)
        }
        for (r in 0 until MAX_OBJECTIVES) {
            Row(Modifier.height(46.dp)) {
                EditableObjective(objectives[r], 150.dp) { onObjectiveChange(r, it) }
                for (d in 0 until days) {
                    val s = states[r][d]
                    Box(
                        Modifier.size(42.dp, 46.dp).border(0.7.dp, Color.Black)
                            .pointerInput(r, d, s) {
                                detectTapGestures(
                                    onTap = { onStateChange(r, d) },
                                    onLongPress = { onFailure(r, d) }
                                )
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            when (s) { 1 -> "✓"; 2 -> "✕"; else -> "" },
                            color = Color.Black, fontSize = 20.sp, fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun Cell(text: String, width: androidx.compose.ui.unit.Dp, header: Boolean) {
    Box(
        Modifier.width(width).fillMaxHeight().border(0.7.dp, Color.Black),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Color.Black, fontWeight = if (header) FontWeight.Bold else FontWeight.Normal, fontSize = 12.sp)
    }
}

@Composable
fun EditableObjective(value: String, width: androidx.compose.ui.unit.Dp, onChange: (String) -> Unit) {
    var text by remember(value) { mutableStateOf(value) }
    androidx.compose.material3.OutlinedTextField(
        value = text, onValueChange = { text = it; onChange(it) },
        modifier = Modifier.width(width).fillMaxHeight().border(0.7.dp, Color.Black),
        singleLine = true,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Color.Black, unfocusedBorderColor = Color.Black,
            focusedTextColor = Color.Black, unfocusedTextColor = Color.Black,
            cursorColor = Color.Black
        ),
        textStyle = LocalTextStyle.current.copy(fontSize = 12.sp),
        placeholder = { Text("Objectif", color = Color.Gray, fontSize = 12.sp) }
    )
}

private fun loadObjectives(key: String): List<String> {
    val p = AppHolder.prefs
    val s = p.getString("obj_$key", null) ?: return List(MAX_OBJECTIVES) { "" }
    val a = JSONArray(s)
    return List(MAX_OBJECTIVES) { i -> if (i < a.length()) a.optString(i) else "" }
}

private fun saveObjectives(key: String, list: List<String>) {
    val a = JSONArray().apply { list.forEach { put(it) } }
    AppHolder.prefs.edit().putString("obj_$key", a.toString()).apply()
}

private fun loadStates(key: String, rows: Int, days: Int): List<List<Int>> {
    val p = AppHolder.prefs
    val s = p.getString("state_$key", null) ?: return List(rows) { List(days) { 0 } }
    val a = JSONArray(s)
    return List(rows) { r ->
        val row = if (r < a.length()) a.optJSONArray(r) else null
        List(days) { d -> row?.optInt(d, 0) ?: 0 }
    }
}

private fun saveStates(key: String, matrix: List<List<Int>>) {
    val a = JSONArray()
    matrix.forEach { row -> a.put(JSONArray(row)) }
    AppHolder.prefs.edit().putString("state_$key", a.toString()).apply()
}

object AppHolder {
    lateinit var prefs: android.content.SharedPreferences
}
