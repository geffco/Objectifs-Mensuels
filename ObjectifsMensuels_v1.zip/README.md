# Objectifs mensuels — v1.0

Application Android personnelle de suivi mensuel.

Fonctions :
- 20 objectifs maximum
- mois précédent/suivant
- tableau scrollable horizontalement
- 4 états par case : vide → réussi → vide → échec → vide
- courbe du nombre de réussites par jour
- statistiques du mois
- sauvegarde locale automatique via SharedPreferences
- fonctionnement hors connexion
- thème noir + tableau blanc

## Construire
Ouvrir le dossier dans Android Studio, laisser Gradle synchroniser puis lancer sur un téléphone Android (SDK 26+).
